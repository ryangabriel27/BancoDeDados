<?php
include 'functions.php';
?>

<?=template_header('Pizzaria Azzip')?>

<div class="content">
    <h2>Inicio</h2>
    <p>Seja Bem-Vindo!</p>
</div>

<?=template_footer()?>